import numpy as np
from flask import Flask, jsonify
import pandas as pd
from tensorflow.keras.models import load_model
from datetime import time
from sklearn.preprocessing import MinMaxScaler

app = Flask(__name__)

# Ruta del CSV en GitHub
CSV_URL = "https://raw.githubusercontent.com/JHYouness/Mislata_proyecto/main/data/data_gold/entrenamiento_neuronal_calefaccion_gold.csv"

# Cargar modelo entrenado (ajustá el nombre del archivo si es necesario)
modelo = load_model("Proyecto_Sensores/model_predicciones_se_abrira.keras")
modelo_temperaturas = load_model("Proyecto_Sensores/model_predict_temperaturas.keras")

def filtrado(df_sucio):
    df_sucio['dia_semana'] = pd.to_datetime(df_sucio['time']).dt.weekday  # 0 = lunes, 6 = domingo

    df = df_sucio

    # Filtra entre las 7:00 y las 21:00 y solo días entre semana (lunes a viernes)
    df = df[
        (df['hora'].between(7, 21)) &
        (df['dia_semana'] < 5)
        ]  # 0-4 para lunes a viernes

    return df


@app.route('/predict_windows', methods=['GET'])
def predict_from_csv():
    try:
        # Leer el CSV desde GitHub
        df_raw = pd.read_csv(CSV_URL)
        df_filtrado = filtrado(df_raw)
        df_predict = limpieza_ultimo_registro(df_filtrado.tail(1))


        resultados = []
        for idx, row in df_predict.iterrows():

            # Asegurate que las columnas coincidan con lo que usaste para entrenar
            features = [
                float(row['sensor.sensor_temperatura_1_humidity']),
                float(row['sensor.sensor_temperatura_1_pressure']),
                float(row['sensor.sensor_temperatura_1_temperature']),
                float(row['sensor_puerta_1 Puerta']),
                float(row['suma_ventanas_arriba']),
                float(row['suma_ventanas_abajo']),
                float(row['azimuth_mean']),
                float(row['elevacion_sol']),
                float(row['temperatura_exterior']),
                float(row['porcentaje_nubes']),
                int(row['part_of_day']),
                int(row['mes']),
                int(row['season']),
                float(row['hora_sin']),
                float(row['hora_cos']),
                bool(row['dia_1']),
                bool(row['dia_2']),
                bool(row['dia_3']),
                bool(row['dia_4']),
                bool(row['dia_5']),
                bool(row['dia_6']),
                float(row['temperatura_predicha'])
            ]

            features_array = np.array([features], dtype=np.float32)
            pred = modelo.predict([features_array])[0]

            estado_ventanas = ""
            if pred >= 0.5:
                estado_ventanas = "Abierto"
            else:
                estado_ventanas = "Cerrado"

            resultados.append({
                "alerta": f" En la próxima hora las ventanas estarán {estado_ventanas}."
            })

        return jsonify({"Predicción": resultados})

    except Exception as e:
        return jsonify({"error_Prediccion_Ventanas": str(e)}), 500


def limpieza_ultimo_registro(df_sucio):
    scaler = MinMaxScaler()

    df_modelo_temperatura = scaler.fit_transform(df_sucio[['sensor.sensor_temperatura_1_humidity',
                                                     'sensor.sensor_temperatura_1_pressure',
                                                     'sensor.sensor_temperatura_1_temperature',
                                                     'sensor_puerta_1 Puerta',
                                                     'suma_ventanas_arriba', 'suma_ventanas_abajo', 'azimuth_mean',
                                                     'elevacion_sol', 'temperatura_exterior', 'porcentaje_nubes',
                                                     'hora', 'part_of_day', 'mes', 'season',
                                                     'hora_sin', 'hora_cos', 'dia_1', 'dia_2', 'dia_3', 'dia_4',
                                                     'dia_5', 'dia_6']])

    df_sucio["temperatura_predicha"] = modelo_temperaturas.predict(df_modelo_temperatura)
    df_sucio['dia_semana'] = pd.to_datetime(df_sucio['time']).dt.weekday  # 0 = lunes, 6 = domingo

    def calefaccion(row):
        if 7 <= row['hora'] < 11 and row['temperatura_predicha'] < 22:
            return True
        elif 11 <= row['hora'] < 16 and row['temperatura_predicha'] < 21:
            return True
        elif 16 <= row['hora'] < 18 and row['temperatura_predicha'] < 21.6:
            return True
        elif 18 <= row['hora'] < 20.67 and row['temperatura_predicha'] < 22:
            return True
        else:
            return False

    # Aplica la función para crear la columna 'calefaccion_encendida'
    df_sucio['calefaccion_encendida'] = df_sucio.apply(calefaccion, axis=1)

    # Filtramos cuando la calefacción está encendida
    df = df_sucio[df_sucio['calefaccion_encendida'] == True]

    # Muestra el resultado
    df.drop(columns=['hora', 'dia_semana', "time", "temperatura_calefaccion_y", "calefaccion_encendida"], inplace=True)

    return df



if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

